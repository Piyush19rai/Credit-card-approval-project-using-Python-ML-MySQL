use cc;
select * from cleaned;

# Question 1. -- Group the customers based on their income type and find the average of their annual income.
select Type_Income, avg(Annual_income) from cleaned group by Type_Income;

# Question 2. -- Find the female owners of cars and property.
select Ind_ID, GENDER, Car_Owner, Propert_Owner from cleaned where(GENDER = 'F' and Car_owner = 'Y' and 
Propert_Owner ='Y');

#Question 3. -- Find the male customers who are staying with their families.
select * from cleaned;
select Ind_ID, GENDER, Marital_status from cleaned where(GENDER = 'M' and Family_Members > 1);

#Question 4. -- Please list the top five people having the highest income.
select * from cleaned;
Select Ind_ID, Annual_income from cleaned order by Annual_income desc limit 5;

#Question 5. -- How many married people are having bad credit?
select * from cleaned;
Select count(*) from cleaned where(Marital_status = 'Married' and label = 1);

#Question 6. -- What is the highest education level and what is the total count?
select * from cleaned;
select EDUCATION, count(*) as counts FROM cleaned group by EDUCATION order by counts desc;

#Question 7. -- Between married males and females, who is having more bad credit?
select * from cleaned;
select Marital_status, GENDER, count(*) as counts
from cleaned where(Marital_status = 'Married' and label = 1)
group by Marital_status, GENDER;